#!/bin/bash

echo "Hello vomolo!"
